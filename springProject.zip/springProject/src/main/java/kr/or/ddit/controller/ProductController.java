package kr.or.ddit.controller;

import kr.or.ddit.vo.ProductVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Slf4j
@Controller
public class ProductController {
    @RequestMapping(value = "/shopping/welcome", method = RequestMethod.GET)
    public ModelAndView welcome(ModelAndView mav) {
        mav.setViewName("shopping/welcome");
        return mav;
    }

    @RequestMapping(value = "shopping/addProduct", method = RequestMethod.GET)
    public ModelAndView addProduct(ModelAndView mav) {
        mav.setViewName("shopping/addProduct");
        return mav;
    }

    @RequestMapping(value = "shopping/products", method = RequestMethod.GET)
    public ModelAndView products(ModelAndView mav) {
        mav.setViewName("shopping/products");
        return mav;
    }

    public ModelAndView processAddProduct(ModelAndView mav, ProductVO vo) {
        mav.setViewName("redirect:/shopping/addProduct");
        return mav;
    }
}
