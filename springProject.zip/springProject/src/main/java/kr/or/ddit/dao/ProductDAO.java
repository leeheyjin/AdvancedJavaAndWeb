package kr.or.ddit.dao;

public class ProductDAO {
}
